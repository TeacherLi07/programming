from setuptools import setup

setup(
    name="readbmp",
    version="0.1",
    description="Testing installation of Package",
    url="#",
    author="auth",
    author_email="jiangyangcreate@gmail.com",
    license="MIT",
    packages=["readbmp"],
    zip_safe=False,
)
